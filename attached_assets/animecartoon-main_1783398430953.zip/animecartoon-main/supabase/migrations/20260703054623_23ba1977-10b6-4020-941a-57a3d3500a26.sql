ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS meta jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS episodes jsonb NOT NULL DEFAULT '[]'::jsonb;