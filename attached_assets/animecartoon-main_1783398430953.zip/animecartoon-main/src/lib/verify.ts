// Client-side verification token gate via shrinkme.io
// Token model: random token, stored in localStorage with 12h expiry.

const STORAGE_KEY = "ps:verify";
const PENDING_KEY = "ps:verify-pending";
const VALIDITY_MS = 12 * 60 * 60 * 1000; // 12 hours

type StoredToken = { token: string; expiresAt: number };
type Pending = { token: string; returnTo: string; createdAt: number };

function readJson<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export function hasValidToken(): boolean {
  if (typeof window === "undefined") return false;
  const stored = readJson<StoredToken>(STORAGE_KEY);
  if (!stored) return false;
  if (stored.expiresAt < Date.now()) {
    localStorage.removeItem(STORAGE_KEY);
    return false;
  }
  return true;
}

export function tokenExpiresAt(): number | null {
  const stored = readJson<StoredToken>(STORAGE_KEY);
  return stored?.expiresAt ?? null;
}

function randomToken(): string {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

export async function startVerification(returnTo: string): Promise<void> {
  const token = randomToken();
  const pending: Pending = { token, returnTo, createdAt: Date.now() };
  localStorage.setItem(PENDING_KEY, JSON.stringify(pending));

  const origin = window.location.origin;
  const destination = `${origin}/verify?token=${token}`;

  // Ask our server to shorten via shrinkme.io
  let shortUrl = destination;
  try {
    const res = await fetch(`/api/public/shorten?url=${encodeURIComponent(destination)}`);
    const data = (await res.json()) as { short?: string };
    if (data.short) shortUrl = data.short;
  } catch {
    // fall back to direct destination
  }
  window.location.href = shortUrl;
}

export function completeVerification(token: string): string | null {
  const pending = readJson<Pending>(PENDING_KEY);
  if (!pending || pending.token !== token) return null;
  const stored: StoredToken = {
    token,
    expiresAt: Date.now() + VALIDITY_MS,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
  localStorage.removeItem(PENDING_KEY);
  return pending.returnTo || "/";
}

export function clearVerification(): void {
  localStorage.removeItem(STORAGE_KEY);
  localStorage.removeItem(PENDING_KEY);
}
