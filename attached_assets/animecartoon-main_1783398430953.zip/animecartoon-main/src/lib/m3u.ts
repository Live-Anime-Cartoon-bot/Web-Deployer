export interface Channel {
  id: string;
  name: string;
  logo: string;
  url: string;
  category: string;
  group: string;
}

const PLAYLIST_URL =
  "https://raw.githubusercontent.com/Live-Anime-Cartoon-bot/Gh/refs/heads/main/M3u";

const FALLBACK_PLAYLIST_URL = "https://iptv-org.github.io/iptv/categories/kids.m3u";

const PINNED_CHANNELS: Channel[] = [
  {
    id: "pogo",
    name: "POGO",
    logo: "https://jiotvimages.cdn.jio.com/dare_images/images/channel/1d47df5bb049d4e70d8d7301ef9666cb.png",
    url: "https://rkdy-xtream.vercel.app/api/live/stream?id=7220&token=rkdyiptv&key=rkdy",
    category: "Cartoon",
    group: "Cartoon",
  },
];

const TRUSTED_FALLBACK_NAMES = [
  "3ABN Kids Network",
  "90's Kids",
  "90s Kids TV 2",
  "13 Kids",
  "ABC Kids",
  "Akili Kids!",
  "Duck TV",
  "Happy Kids",
  "Kartoon Channel!",
  "Kidoodle TV",
  "KidsFlix",
  "PBS Kids",
  "Ryan and Friends",
  "Toon Goggles",
];

const BAD_STREAM_MARKERS = [
  "content not subscribed",
  "not found",
  "access denied",
  "forbidden",
  "expired",
  "invalid token",
  "error 404",
];

function slug(s: string) {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function categoryOf(name: string): string {
  const n = name.toLowerCase();
  if (/(nick jr|kids nursery|chuchu|jugnu|disney junior)/.test(n)) return "Kids";
  if (/(cartoon network|pogo|sonic|disney|nick|hungama|discovery)/.test(n)) return "Cartoon";
  if (/(doraemon|shinchan|oggy|crayon|anime|naruto|one piece)/.test(n)) return "Anime";
  if (/(little singham|chhota bheem|krishna|motu|gattu|chacha|kid krrish|vir |kicko|mighty raju|super bheem|roll no 21|tom and jerry|mickey)/.test(n))
    return "Cartoon";
  return "Live TV";
}

function channelKey(channel: Pick<Channel, "id" | "name">): string {
  return slug(channel.id || channel.name);
}

function withPinnedChannels(channels: Channel[]): Channel[] {
  const pinnedKeys = new Set(PINNED_CHANNELS.map(channelKey));
  const pinnedNames = new Set(PINNED_CHANNELS.map((channel) => channel.name.toLowerCase()));
  const rest = channels.filter(
    (channel) => !pinnedKeys.has(channelKey(channel)) && !pinnedNames.has(channel.name.toLowerCase()),
  );
  return [...PINNED_CHANNELS, ...rest];
}

async function fetchWithTimeout(url: string, timeoutMs = 8_000): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { cache: "no-store", signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

export function parseM3U(text: string): Channel[] {
  const lines = text.split(/\r?\n/);
  const channels: Channel[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.startsWith("#EXTINF")) continue;
    const logo = line.match(/tvg-logo="([^"]*)"/)?.[1] ?? "";
    const group = line.match(/group-title="([^"]*)"/)?.[1] ?? "";
    const name = line.split(",").slice(1).join(",").trim();
    const url = (lines[i + 1] ?? "").trim();
    if (!url || url.startsWith("#")) continue;
    let id = slug(name) || `ch-${channels.length}`;
    let n = 1;
    while (seen.has(id)) id = `${slug(name)}-${n++}`;
    seen.add(id);
    channels.push({
      id,
      name,
      logo,
      url,
      group,
      category: group || categoryOf(name),
    });
  }
  return channels;
}

async function isPlayableChannel(channel: Channel): Promise<boolean> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5_000);

  try {
    const res = await fetch(channel.url, {
      cache: "no-store",
      redirect: "follow",
      signal: controller.signal,
      headers: {
        Range: "bytes=0-511",
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
      },
    });

    if (!res.ok) return false;

    const contentType = res.headers.get("content-type")?.toLowerCase() ?? "";
    const bytes = new Uint8Array(await res.arrayBuffer());
    const preview = new TextDecoder().decode(bytes.slice(0, 512)).toLowerCase();

    if (BAD_STREAM_MARKERS.some((marker) => preview.includes(marker))) return false;
    if (preview.trimStart().startsWith("#extm3u")) return true;
    if (contentType.includes("mpegurl")) return true;
    if (bytes[0] === 0x47) return true;
    if (contentType.includes("video/mp2t") && bytes.length > 0) return true;

    return false;
  } catch {
    return false;
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchFallbackChannels(): Promise<Channel[]> {
  try {
    const res = await fetchWithTimeout(FALLBACK_PLAYLIST_URL);
    if (!res.ok) return [];
    return parseM3U(await res.text())
      .filter((channel) => TRUSTED_FALLBACK_NAMES.some((name) => channel.name.includes(name)))
      .map((channel) => ({
        ...channel,
        category: "Kids",
        group: channel.group || "Kids",
      }));
  } catch {
    return [];
  }
}

export async function filterPlayableChannels(
  channels: Channel[],
  options: { keepOriginalOnEmpty?: boolean } = {},
): Promise<Channel[]> {
  const keepOriginalOnEmpty = options.keepOriginalOnEmpty ?? true;
  const playable: Channel[] = [];
  const chunkSize = 8;

  for (let i = 0; i < channels.length; i += chunkSize) {
    const chunk = channels.slice(i, i + chunkSize);
    const results = await Promise.all(chunk.map((channel) => isPlayableChannel(channel)));
    results.forEach((ok, index) => {
      if (ok) playable.push(chunk[index]);
    });
  }

  return playable.length || !keepOriginalOnEmpty ? playable : channels;
}

export function channelsToM3U(channels: Channel[]): string {
  const lines = ["#EXTM3U"];
  channels.forEach((channel) => {
    const attrs = [
      channel.logo ? `tvg-logo="${channel.logo}"` : "",
      channel.group ? `group-title="${channel.group}"` : "",
    ]
      .filter(Boolean)
      .join(" ");
    lines.push(`#EXTINF:-1${attrs ? ` ${attrs}` : ""},${channel.name}`);
    lines.push(channel.url);
  });
  return `${lines.join("\n")}\n`;
}

export async function fetchChannels(): Promise<Channel[]> {
  if (typeof window === "undefined") return fetchPublicPlaylistChannels();

  const url = typeof window === "undefined" ? PLAYLIST_URL : "/api/public/playlist";
  let m3uChannels: Channel[] = [];
  try {
    const res = await fetch(url, { cache: "no-store" });
    if (res.ok) m3uChannels = parseM3U(await res.text());
  } catch {
    // keep Live TV open even if the public playlist endpoint is slow/down
  }

  if (typeof window !== "undefined") {
    try {
      const { supabase } = await import("@/integrations/supabase/client");
      const { data } = await supabase
        .from("channels")
        .select("slug,name,logo,stream_url,category,sort_order")
        .eq("active", true)
        .order("sort_order", { ascending: true });
      const dbChannels: Channel[] = (data ?? []).map((c) => ({
        id: c.slug,
        name: c.name,
        logo: c.logo ?? "",
        url: c.stream_url,
        group: c.category ?? "Live TV",
        category: c.category ?? "Live TV",
      }));
      const seen = new Set(dbChannels.map((c) => c.id));
      return withPinnedChannels([...dbChannels, ...m3uChannels.filter((c) => !seen.has(c.id))]);
    } catch {
      // ignore DB errors, fall back to M3U only
    }
  }
  return withPinnedChannels(m3uChannels);
}

export async function fetchPublicPlaylistChannels(
  options: { probe?: boolean } = {},
): Promise<Channel[]> {
  const probe = options.probe ?? false;
  let parsedChannels: Channel[] = [];
  try {
    const upstream = await fetchWithTimeout(PLAYLIST_URL);
    parsedChannels = upstream.ok ? parseM3U(await upstream.text()) : [];
  } catch {
    parsedChannels = [];
  }
  const primaryChannels = probe
    ? await filterPlayableChannels(parsedChannels, { keepOriginalOnEmpty: false })
    : parsedChannels;
  if (primaryChannels.length > 0) return withPinnedChannels(primaryChannels);
  const fallbackChannels = await fetchFallbackChannels();
  return withPinnedChannels(fallbackChannels);
}

export { FALLBACK_PLAYLIST_URL, PLAYLIST_URL };

