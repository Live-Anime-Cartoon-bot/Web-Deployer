import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Shield, LogOut, LayoutDashboard, FileText, FolderTree, Tags as TagsIcon,
  File, Tv, MessageSquare, Plus, Trash2, Save, Loader2, Eye, EyeOff, Check,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useRoles, slugify } from "@/lib/auth-hooks";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin · Anime Cartoon" }, { name: "robots", content: "noindex,nofollow" }] }),
  component: AdminRoot,
});

type Section = "dashboard" | "posts" | "categories" | "tags" | "livetv" | "channel-add" | "pages" | "comments";

function AdminRoot() {
  const navigate = useNavigate();
  const { session, loading: sLoading } = useSession();
  const { roles, loading: rLoading, isAdmin, isEditor } = useRoles(session?.user.id);
  const [section, setSection] = useState<Section>("dashboard");

  useEffect(() => {
    if (!sLoading && !session) navigate({ to: "/auth" });
  }, [sLoading, session, navigate]);

  if (sLoading || rLoading) {
    return <div className="grid min-h-screen place-items-center bg-background text-muted-foreground">
      <Loader2 className="h-6 w-6 animate-spin" /></div>;
  }
  if (!session) return null;
  if (!isEditor) {
    return (
      <div className="grid min-h-screen place-items-center bg-background px-4 text-center">
        <div>
          <Shield className="mx-auto h-10 w-10 text-destructive" />
          <h1 className="mt-4 text-xl font-semibold">Not authorised</h1>
          <p className="mt-1 text-sm text-muted-foreground">Your account ({session.user.email}) has no admin role.</p>
          <p className="mt-1 text-xs text-muted-foreground">Roles: {roles.join(", ") || "none"}</p>
          <button
            onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/auth" }); }}
            className="mt-4 rounded-full bg-surface px-4 py-2 text-xs font-medium hover:text-foreground"
          >Sign out</button>
        </div>
      </div>
    );
  }

  const nav: { id: Section; label: string; icon: React.ReactNode; group?: string }[] = [
    { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-4 w-4" /> },
    { id: "posts", label: "All Posts", icon: <FileText className="h-4 w-4" />, group: "Posts" },
    { id: "categories", label: "Categories", icon: <FolderTree className="h-4 w-4" />, group: "Posts" },
    { id: "tags", label: "Tags", icon: <TagsIcon className="h-4 w-4" />, group: "Posts" },
    { id: "livetv", label: "Live TV", icon: <Tv className="h-4 w-4" />, group: "Live TV" },
    { id: "channel-add", label: "Channel Add", icon: <Plus className="h-4 w-4" />, group: "Live TV" },
    { id: "pages", label: "Pages", icon: <File className="h-4 w-4" /> },
    { id: "comments", label: "Comments", icon: <MessageSquare className="h-4 w-4" /> },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1400px] items-center gap-3 px-4 py-3">
          <span className="grid h-9 w-9 place-items-center rounded-xl gradient-brand shadow-glow">
            <Shield className="h-4 w-4 text-primary-foreground" />
          </span>
          <div>
            <h1 className="text-sm font-semibold">Anime Cartoon Admin</h1>
            <p className="text-[11px] text-muted-foreground">{session.user.email} · {isAdmin ? "admin" : "editor"}</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Link to="/" className="rounded-full bg-surface px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground">View Site</Link>
            <button
              onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/auth" }); }}
              className="flex items-center gap-1.5 rounded-full bg-surface px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
            ><LogOut className="h-3.5 w-3.5" /> Sign out</button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1400px] gap-6 px-4 py-6">
        <aside className="hidden w-56 shrink-0 md:block">
          <nav className="sticky top-20 space-y-1">
            {nav.map((n, i) => {
              const prevGroup = i > 0 ? nav[i - 1].group : undefined;
              return (
                <div key={n.id}>
                  {n.group && n.group !== prevGroup && (
                    <div className="mt-4 px-3 pb-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{n.group}</div>
                  )}
                  <button
                    onClick={() => setSection(n.id)}
                    className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm transition ${
                      section === n.id ? "gradient-brand text-primary-foreground shadow-glow" : "text-muted-foreground hover:bg-surface hover:text-foreground"
                    }`}
                  >{n.icon} {n.label}</button>
                </div>
              );
            })}
          </nav>
        </aside>

        <main className="min-w-0 flex-1">
          <div className="mb-4 flex gap-2 overflow-x-auto md:hidden">
            {nav.map((n) => (
              <button key={n.id} onClick={() => setSection(n.id)}
                className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-medium ${section === n.id ? "gradient-brand text-primary-foreground" : "bg-surface text-muted-foreground"}`}>
                {n.label}
              </button>
            ))}
          </div>
          {section === "dashboard" && <Dashboard />}
          {section === "posts" && <PostsManager />}
          {section === "categories" && <TaxManager kind="categories" />}
          {section === "tags" && <TaxManager kind="tags" />}
          {section === "pages" && <PagesManager />}
          {section === "livetv" && <ChannelsList />}
          {section === "channel-add" && <ChannelForm onDone={() => setSection("livetv")} />}
          {section === "comments" && <CommentsManager />}
        </main>
      </div>
    </div>
  );
}

/* ---------------- Dashboard ---------------- */
function Dashboard() {
  const [stats, setStats] = useState({ posts: 0, pages: 0, channels: 0, pending: 0 });
  useEffect(() => {
    (async () => {
      const [p, pg, ch, cm] = await Promise.all([
        supabase.from("posts").select("id", { count: "exact", head: true }),
        supabase.from("pages").select("id", { count: "exact", head: true }),
        supabase.from("channels").select("id", { count: "exact", head: true }),
        supabase.from("comments").select("id", { count: "exact", head: true }).eq("approved", false),
      ]);
      setStats({ posts: p.count ?? 0, pages: pg.count ?? 0, channels: ch.count ?? 0, pending: cm.count ?? 0 });
    })();
  }, []);
  return (
    <div>
      <h2 className="text-2xl font-bold">Dashboard</h2>
      <p className="text-sm text-muted-foreground">Overview of your site.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Posts" value={stats.posts} icon={<FileText className="h-5 w-5" />} />
        <Stat label="Pages" value={stats.pages} icon={<File className="h-5 w-5" />} />
        <Stat label="Channels" value={stats.channels} icon={<Tv className="h-5 w-5" />} />
        <Stat label="Pending comments" value={stats.pending} icon={<MessageSquare className="h-5 w-5" />} />
      </div>
    </div>
  );
}
function Stat({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="rounded-3xl border border-border bg-surface p-5 shadow-card">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl gradient-brand text-primary-foreground shadow-glow">{icon}</span>
        <div>
          <div className="text-2xl font-bold">{value}</div>
          <div className="text-xs text-muted-foreground">{label}</div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Posts ---------------- */
type PostMeta = {
  series_name?: string; release_date?: string; total_parts?: string; duration?: string;
  file_size?: string; languages?: string; video_quality?: string; encoded_by?: string;
};
type Episode = { label: string; image?: string; download_url?: string; watch_url?: string };
type Post = { id: string; title: string; slug: string; excerpt: string | null; html: string; cover_image: string | null; category_id: string | null; tags: string[]; published: boolean; published_at: string | null; created_at: string; meta?: PostMeta; episodes?: Episode[] };

function PostsManager() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [editing, setEditing] = useState<Post | "new" | null>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("posts").select("*").order("created_at", { ascending: false });
    setPosts((data ?? []) as unknown as Post[]);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  if (editing) return <PostEditor post={editing === "new" ? null : editing} onDone={() => { setEditing(null); load(); }} />;

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">All Posts</h2>
          <p className="text-sm text-muted-foreground">Blog posts with custom HTML body.</p>
        </div>
        <button onClick={() => setEditing("new")}
          className="flex items-center gap-1.5 rounded-full gradient-brand px-4 py-2 text-xs font-semibold text-primary-foreground shadow-glow">
          <Plus className="h-4 w-4" /> Add Post
        </button>
      </div>
      <div className="rounded-3xl border border-border bg-surface shadow-card overflow-hidden">
        {loading ? <div className="p-8 text-center text-muted-foreground text-sm">Loading…</div> :
          posts.length === 0 ? <div className="p-8 text-center text-muted-foreground text-sm">No posts yet. Create your first one.</div> :
          <table className="w-full text-sm">
            <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-5 py-3">Title</th>
                <th className="px-5 py-3">Slug</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {posts.map((p) => (
                <tr key={p.id} className="border-b border-border/60 last:border-0 hover:bg-surface-2">
                  <td className="px-5 py-3 font-medium">{p.title}</td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">{p.slug}</td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-[11px] ${p.published ? "bg-emerald-500/20 text-emerald-400" : "bg-yellow-500/20 text-yellow-400"}`}>
                      {p.published ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <button onClick={() => setEditing(p)} className="mr-2 text-xs text-accent hover:underline">Edit</button>
                    <button onClick={async () => {
                      if (!confirm(`Delete "${p.title}"?`)) return;
                      await supabase.from("posts").delete().eq("id", p.id);
                      load();
                    }} className="text-xs text-destructive hover:underline">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        }
      </div>
    </div>
  );
}

function PostEditor({ post, onDone }: { post: Post | null; onDone: () => void }) {
  const [title, setTitle] = useState(post?.title ?? "");
  const [slug, setSlug] = useState(post?.slug ?? "");
  const [excerpt, setExcerpt] = useState(post?.excerpt ?? "");
  const [html, setHtml] = useState(post?.html ?? "");
  const [cover, setCover] = useState(post?.cover_image ?? "");
  const [categoryId, setCategoryId] = useState(post?.category_id ?? "");
  const [tagsInput, setTagsInput] = useState(post?.tags?.join(", ") ?? "");
  const [published, setPublished] = useState(post?.published ?? false);
  const [meta, setMeta] = useState<PostMeta>(post?.meta ?? {});
  const [episodes, setEpisodes] = useState<Episode[]>(post?.episodes ?? []);
  const [cats, setCats] = useState<{ id: string; name: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => { supabase.from("categories").select("id,name").order("name").then(({ data }) => setCats(data ?? [])); }, []);
  useEffect(() => { if (!post && title && !slug) setSlug(slugify(title)); }, [title, post, slug]);

  function setMetaField(k: keyof PostMeta, v: string) { setMeta((m) => ({ ...m, [k]: v })); }
  function addEpisode() { setEpisodes((e) => [...e, { label: `Episode ${String(e.length + 1).padStart(2, "0")}` }]); }
  function updateEpisode(i: number, patch: Partial<Episode>) {
    setEpisodes((e) => e.map((ep, idx) => idx === i ? { ...ep, ...patch } : ep));
  }
  function removeEpisode(i: number) { setEpisodes((e) => e.filter((_, idx) => idx !== i)); }

  async function save() {
    setBusy(true); setErr(null);
    const payload = {
      title, slug: slug || slugify(title), excerpt: excerpt || null,
      html, cover_image: cover || null,
      category_id: categoryId || null,
      tags: tagsInput.split(",").map((t) => t.trim()).filter(Boolean),
      published, published_at: published ? new Date().toISOString() : null,
      meta, episodes,
      author_id: (await supabase.auth.getUser()).data.user?.id,
    };
    const { error } = post
      ? await supabase.from("posts").update(payload).eq("id", post.id)
      : await supabase.from("posts").insert(payload);
    setBusy(false);
    if (error) { setErr(error.message); return; }
    onDone();
  }

  return (
    <div>
      <div className="mb-4 flex items-center gap-3">
        <button onClick={onDone} className="text-xs text-muted-foreground hover:text-foreground">← Back</button>
        <h2 className="text-2xl font-bold">{post ? "Edit Post" : "Add Post"}</h2>
      </div>
      <div className="grid gap-4 lg:grid-cols-[1fr,320px]">
        <div className="space-y-4">
          <div className="rounded-3xl border border-border bg-surface p-5 shadow-card">
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Add title"
              className="w-full bg-transparent text-2xl font-bold outline-none placeholder:text-muted-foreground" />
            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <span>Slug:</span>
              <input value={slug} onChange={(e) => setSlug(slugify(e.target.value))}
                className="flex-1 rounded-md border border-border bg-background px-2 py-1" placeholder="my-post-slug" />
            </div>
          </div>
          <div className="rounded-3xl border border-border bg-surface p-5 shadow-card">
            <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Custom HTML</label>
            <textarea value={html} onChange={(e) => setHtml(e.target.value)}
              className="h-96 w-full rounded-xl border border-border bg-background p-3 font-mono text-xs outline-none focus:border-brand"
              placeholder="<p>Write your post in HTML…</p>" />
            <p className="mt-2 text-[11px] text-muted-foreground">HTML is rendered as-is on the post page. Only admins/editors can post — HTML you enter is trusted.</p>
          </div>

          <div className="rounded-3xl border border-border bg-surface p-5 shadow-card">
            <label className="mb-3 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Series / Movie Details</label>
            <div className="grid gap-3 sm:grid-cols-2">
              {([
                ["series_name", "Series Name"],
                ["release_date", "Release Date"],
                ["total_parts", "Total Parts / Episodes"],
                ["duration", "Duration"],
                ["file_size", "File Size"],
                ["languages", "Languages"],
                ["video_quality", "Video Quality"],
                ["encoded_by", "Encoded By"],
              ] as [keyof PostMeta, string][]).map(([k, label]) => (
                <label key={k} className="block">
                  <span className="mb-1 block text-[11px] font-semibold text-muted-foreground">{label}</span>
                  <input value={meta[k] ?? ""} onChange={(e) => setMetaField(k, e.target.value)}
                    className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
                </label>
              ))}
            </div>
            <p className="mt-3 text-[11px] text-muted-foreground">Leave blank to hide a row on the post page.</p>
          </div>

          <div className="rounded-3xl border border-border bg-surface p-5 shadow-card">
            <div className="mb-3 flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">Episodes / Download Links</label>
              <button onClick={addEpisode} type="button"
                className="flex items-center gap-1 rounded-full bg-background px-3 py-1 text-[11px] font-semibold text-accent hover:bg-surface-2">
                <Plus className="h-3 w-3" /> Add Episode
              </button>
            </div>
            {episodes.length === 0 && <p className="text-xs text-muted-foreground">No episodes yet. Add one to show a "Select Episode" dropdown with download and watch buttons on the post page.</p>}
            <div className="space-y-3">
              {episodes.map((ep, i) => (
                <div key={i} className="rounded-xl border border-border bg-background p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Episode {i + 1}</span>
                    <button onClick={() => removeEpisode(i)} type="button" className="text-[11px] text-destructive hover:underline">Remove</button>
                  </div>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <input value={ep.label} onChange={(e) => updateEpisode(i, { label: e.target.value })}
                      placeholder="Label e.g. Episode 01 – Part 1" className="rounded-lg border border-border bg-surface px-3 py-2 text-sm" />
                    <input value={ep.image ?? ""} onChange={(e) => updateEpisode(i, { image: e.target.value })}
                      placeholder="Image URL (optional)" className="rounded-lg border border-border bg-surface px-3 py-2 text-sm" />
                    <input value={ep.watch_url ?? ""} onChange={(e) => updateEpisode(i, { watch_url: e.target.value })}
                      placeholder="Watch Online URL" className="rounded-lg border border-border bg-surface px-3 py-2 text-sm" />
                    <input value={ep.download_url ?? ""} onChange={(e) => updateEpisode(i, { download_url: e.target.value })}
                      placeholder="Download URL" className="rounded-lg border border-border bg-surface px-3 py-2 text-sm" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {html && (
            <div className="rounded-3xl border border-border bg-surface p-5 shadow-card">
              <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Preview</label>
              <div className="prose prose-invert max-w-none text-sm" dangerouslySetInnerHTML={{ __html: html }} />
            </div>
          )}
        </div>
        <aside className="space-y-4">
          <div className="rounded-3xl border border-border bg-surface p-5 shadow-card space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold">Status</span>
              <button onClick={() => setPublished(!published)} className={`flex items-center gap-1 rounded-full px-3 py-1 text-xs ${published ? "bg-emerald-500/20 text-emerald-400" : "bg-yellow-500/20 text-yellow-400"}`}>
                {published ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                {published ? "Published" : "Draft"}
              </button>
            </div>
            {err && <p className="text-xs text-destructive">{err}</p>}
            <button onClick={save} disabled={busy || !title}
              className="flex w-full items-center justify-center gap-2 rounded-xl gradient-brand py-2.5 text-sm font-semibold text-primary-foreground shadow-glow disabled:opacity-60">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
            </button>
          </div>
          <div className="rounded-3xl border border-border bg-surface p-5 shadow-card space-y-3">
            <label className="block">
              <span className="mb-1 block text-xs font-semibold">Category</span>
              <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm">
                <option value="">— none —</option>
                {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="mb-1 block text-xs font-semibold">Tags (comma separated)</span>
              <input value={tagsInput} onChange={(e) => setTagsInput(e.target.value)}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm" placeholder="news, launch, tv" />
            </label>
            <label className="block">
              <span className="mb-1 block text-xs font-semibold">Cover image URL</span>
              <input value={cover} onChange={(e) => setCover(e.target.value)}
                className="w-full rounded-xl border border-border bg-background px-3 py-2 text-sm" placeholder="https://…" />
            </label>
            <label className="block">
              <span className="mb-1 block text-xs font-semibold">Excerpt</span>
              <textarea value={excerpt ?? ""} onChange={(e) => setExcerpt(e.target.value)}
                className="h-20 w-full rounded-xl border border-border bg-background px-3 py-2 text-sm" placeholder="Short summary…" />
            </label>
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ---------------- Taxonomies (Categories/Tags) ---------------- */
function TaxManager({ kind }: { kind: "categories" | "tags" }) {
  const [items, setItems] = useState<{ id: string; name: string; slug: string }[]>([]);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  async function load() {
    const { data } = await supabase.from(kind).select("id,name,slug").order("name");
    setItems(data ?? []);
  }
  useEffect(() => { load(); }, [kind]);
  return (
    <div>
      <h2 className="text-2xl font-bold capitalize">{kind}</h2>
      <p className="text-sm text-muted-foreground">Organise your posts.</p>
      <div className="mt-4 flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder={`New ${kind.slice(0, -1)} name`}
          className="flex-1 rounded-xl border border-border bg-surface px-4 py-2.5 text-sm outline-none focus:border-brand" />
        <button disabled={!name || busy} onClick={async () => {
          setBusy(true);
          await supabase.from(kind).insert({ name, slug: slugify(name) });
          setName(""); setBusy(false); load();
        }} className="rounded-xl gradient-brand px-4 py-2.5 text-xs font-semibold text-primary-foreground shadow-glow disabled:opacity-60">Add</button>
      </div>
      <div className="mt-4 rounded-3xl border border-border bg-surface shadow-card overflow-hidden">
        {items.length === 0 ? <div className="p-6 text-center text-sm text-muted-foreground">Nothing yet.</div> :
          <ul className="divide-y divide-border/60">
            {items.map((c) => (
              <li key={c.id} className="flex items-center justify-between px-5 py-3 text-sm">
                <div><span className="font-medium">{c.name}</span> <span className="ml-2 text-xs text-muted-foreground">{c.slug}</span></div>
                <button onClick={async () => { if (confirm(`Delete ${c.name}?`)) { await supabase.from(kind).delete().eq("id", c.id); load(); } }}
                  className="text-xs text-destructive hover:underline">Delete</button>
              </li>
            ))}
          </ul>}
      </div>
    </div>
  );
}

/* ---------------- Pages ---------------- */
type Page = { id: string; title: string; slug: string; html: string; published: boolean };
function PagesManager() {
  const [pages, setPages] = useState<Page[]>([]);
  const [editing, setEditing] = useState<Page | "new" | null>(null);
  async function load() {
    const { data } = await supabase.from("pages").select("*").order("created_at", { ascending: false });
    setPages((data ?? []) as Page[]);
  }
  useEffect(() => { load(); }, []);
  if (editing) return <PageEditor page={editing === "new" ? null : editing} onDone={() => { setEditing(null); load(); }} />;
  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Pages</h2>
          <p className="text-sm text-muted-foreground">Static pages like About, Contact.</p>
        </div>
        <button onClick={() => setEditing("new")}
          className="flex items-center gap-1.5 rounded-full gradient-brand px-4 py-2 text-xs font-semibold text-primary-foreground shadow-glow">
          <Plus className="h-4 w-4" /> Add Page
        </button>
      </div>
      <div className="rounded-3xl border border-border bg-surface shadow-card overflow-hidden">
        {pages.length === 0 ? <div className="p-8 text-center text-sm text-muted-foreground">No pages yet.</div> :
          <ul className="divide-y divide-border/60">
            {pages.map((p) => (
              <li key={p.id} className="flex items-center justify-between px-5 py-3 text-sm">
                <div>
                  <div className="font-medium">{p.title}</div>
                  <div className="text-xs text-muted-foreground">/pages/{p.slug} · {p.published ? "Published" : "Draft"}</div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setEditing(p)} className="text-xs text-accent hover:underline">Edit</button>
                  <button onClick={async () => { if (confirm("Delete?")) { await supabase.from("pages").delete().eq("id", p.id); load(); } }}
                    className="text-xs text-destructive hover:underline">Delete</button>
                </div>
              </li>
            ))}
          </ul>}
      </div>
    </div>
  );
}
function PageEditor({ page, onDone }: { page: Page | null; onDone: () => void }) {
  const [title, setTitle] = useState(page?.title ?? "");
  const [slug, setSlug] = useState(page?.slug ?? "");
  const [html, setHtml] = useState(page?.html ?? "");
  const [published, setPublished] = useState(page?.published ?? true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { if (!page && title && !slug) setSlug(slugify(title)); }, [title, page, slug]);
  async function save() {
    setBusy(true); setErr(null);
    const payload = { title, slug: slug || slugify(title), html, published };
    const { error } = page
      ? await supabase.from("pages").update(payload).eq("id", page.id)
      : await supabase.from("pages").insert(payload);
    setBusy(false);
    if (error) return setErr(error.message);
    onDone();
  }
  return (
    <div>
      <div className="mb-4 flex items-center gap-3">
        <button onClick={onDone} className="text-xs text-muted-foreground hover:text-foreground">← Back</button>
        <h2 className="text-2xl font-bold">{page ? "Edit Page" : "Add Page"}</h2>
      </div>
      <div className="rounded-3xl border border-border bg-surface p-5 shadow-card">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Add title"
          className="w-full bg-transparent text-2xl font-bold outline-none placeholder:text-muted-foreground" />
        <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
          <span>Page link: /pages/</span>
          <input value={slug} onChange={(e) => setSlug(slugify(e.target.value))}
            className="flex-1 rounded-md border border-border bg-background px-2 py-1" placeholder="about-us" />
        </div>
      </div>
      <div className="mt-4 rounded-3xl border border-border bg-surface p-5 shadow-card">
        <label className="mb-2 block text-xs font-bold uppercase tracking-wider text-muted-foreground">Custom HTML</label>
        <textarea value={html} onChange={(e) => setHtml(e.target.value)}
          className="h-96 w-full rounded-xl border border-border bg-background p-3 font-mono text-xs outline-none focus:border-brand"
          placeholder="<h1>About us…</h1>" />
      </div>
      <div className="mt-4 flex items-center gap-3">
        <button onClick={() => setPublished(!published)}
          className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-xs ${published ? "bg-emerald-500/20 text-emerald-400" : "bg-yellow-500/20 text-yellow-400"}`}>
          {published ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
          {published ? "Published" : "Draft"}
        </button>
        <button onClick={save} disabled={busy || !title}
          className="ml-auto flex items-center gap-2 rounded-xl gradient-brand px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow disabled:opacity-60">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
        </button>
      </div>
      {err && <p className="mt-2 text-xs text-destructive">{err}</p>}
    </div>
  );
}

/* ---------------- Channels ---------------- */
type ChannelRow = { id: string; name: string; slug: string; logo: string | null; stream_url: string; category: string; active: boolean; sort_order: number };
function ChannelsList() {
  const [rows, setRows] = useState<ChannelRow[]>([]);
  const [editing, setEditing] = useState<ChannelRow | null>(null);
  async function load() {
    const { data } = await supabase.from("channels").select("*").order("sort_order").order("name");
    setRows((data ?? []) as ChannelRow[]);
  }
  useEffect(() => { load(); }, []);
  if (editing) return <ChannelForm channel={editing} onDone={() => { setEditing(null); load(); }} />;
  return (
    <div>
      <h2 className="text-2xl font-bold">Live TV Channels</h2>
      <p className="text-sm text-muted-foreground">Admin-added channels shown on the site alongside the M3U playlist.</p>
      <div className="mt-4 rounded-3xl border border-border bg-surface shadow-card overflow-hidden">
        {rows.length === 0 ? <div className="p-8 text-center text-sm text-muted-foreground">No custom channels yet. Use "Channel Add" to create one.</div> :
          <table className="w-full text-sm">
            <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-5 py-3">Channel</th>
                <th className="px-5 py-3">Category</th>
                <th className="px-5 py-3">Active</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id} className="border-b border-border/60 last:border-0">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 overflow-hidden rounded-full bg-background ring-1 ring-border">
                        {c.logo && <img src={c.logo} alt="" className="h-full w-full object-cover" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />}
                      </div>
                      <span className="font-medium">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">{c.category}</td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-[11px] ${c.active ? "bg-emerald-500/20 text-emerald-400" : "bg-muted text-muted-foreground"}`}>
                      {c.active ? "Yes" : "No"}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <button onClick={() => setEditing(c)} className="mr-3 text-xs text-accent hover:underline">Edit</button>
                    <button onClick={async () => { if (confirm(`Delete ${c.name}?`)) { await supabase.from("channels").delete().eq("id", c.id); load(); } }}
                      className="text-xs text-destructive hover:underline">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>}
      </div>
    </div>
  );
}
function ChannelForm({ channel, onDone }: { channel?: ChannelRow; onDone: () => void }) {
  const [name, setName] = useState(channel?.name ?? "");
  const [slug, setSlug] = useState(channel?.slug ?? "");
  const [logo, setLogo] = useState(channel?.logo ?? "");
  const [streamUrl, setStreamUrl] = useState(channel?.stream_url ?? "");
  const [category, setCategory] = useState(channel?.category ?? "Live TV");
  const [active, setActive] = useState(channel?.active ?? true);
  const [sortOrder, setSortOrder] = useState(channel?.sort_order ?? 0);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { if (!channel && name && !slug) setSlug(slugify(name)); }, [name, channel, slug]);
  async function save() {
    setBusy(true); setErr(null);
    const payload = { name, slug: slug || slugify(name), logo: logo || null, stream_url: streamUrl, category, active, sort_order: sortOrder };
    const { error } = channel
      ? await supabase.from("channels").update(payload).eq("id", channel.id)
      : await supabase.from("channels").insert(payload);
    setBusy(false);
    if (error) return setErr(error.message);
    onDone();
  }
  return (
    <div>
      <div className="mb-4 flex items-center gap-3">
        <button onClick={onDone} className="text-xs text-muted-foreground hover:text-foreground">← Back</button>
        <h2 className="text-2xl font-bold">{channel ? "Edit Channel" : "Channel Add"}</h2>
      </div>
      <div className="rounded-3xl border border-border bg-surface p-5 shadow-card space-y-3">
        <Field label="Name">
          <input value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm outline-none focus:border-brand" placeholder="Cartoon Network HD" />
        </Field>
        <Field label="Slug (URL)">
          <input value={slug} onChange={(e) => setSlug(slugify(e.target.value))} className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm" placeholder="cartoon-network-hd" />
        </Field>
        <Field label="Logo URL">
          <input value={logo} onChange={(e) => setLogo(e.target.value)} className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm" placeholder="https://…/logo.png" />
        </Field>
        <Field label="Stream URL (m3u8 or ts)">
          <input value={streamUrl} onChange={(e) => setStreamUrl(e.target.value)} className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm" placeholder="https://…/index.m3u8" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Category">
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm">
              {["Live TV", "Cartoon", "Anime", "Kids", "Movies", "Sports", "News", "Music"].map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Sort order">
            <input type="number" value={sortOrder} onChange={(e) => setSortOrder(Number(e.target.value))} className="w-full rounded-xl border border-border bg-background px-4 py-2.5 text-sm" />
          </Field>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} /> Active (visible on site)
        </label>
        {err && <p className="text-xs text-destructive">{err}</p>}
        <button onClick={save} disabled={busy || !name || !streamUrl}
          className="flex w-full items-center justify-center gap-2 rounded-xl gradient-brand py-3 text-sm font-semibold text-primary-foreground shadow-glow disabled:opacity-60">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save channel
        </button>
      </div>
    </div>
  );
}

/* ---------------- Comments ---------------- */
type CommentRow = { id: string; post_id: string; author_name: string; body: string; approved: boolean; created_at: string };
function CommentsManager() {
  const [tab, setTab] = useState<"pending" | "approved">("pending");
  const [rows, setRows] = useState<CommentRow[]>([]);
  const [posts, setPosts] = useState<Record<string, string>>({});
  async function load() {
    const { data } = await supabase.from("comments").select("*").eq("approved", tab === "approved").order("created_at", { ascending: false });
    setRows((data ?? []) as CommentRow[]);
    const ids = Array.from(new Set((data ?? []).map((c) => c.post_id)));
    if (ids.length) {
      const { data: ps } = await supabase.from("posts").select("id,title").in("id", ids);
      const map: Record<string, string> = {};
      (ps ?? []).forEach((p) => (map[p.id] = p.title));
      setPosts(map);
    }
  }
  useEffect(() => { load(); }, [tab]);
  return (
    <div>
      <h2 className="text-2xl font-bold">Comments</h2>
      <p className="text-sm text-muted-foreground">Moderate reader comments.</p>
      <div className="mt-4 flex gap-2">
        {(["pending", "approved"] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`rounded-full px-4 py-1.5 text-xs font-medium capitalize ${tab === t ? "gradient-brand text-primary-foreground shadow-glow" : "bg-surface text-muted-foreground"}`}>
            {t}
          </button>
        ))}
      </div>
      <div className="mt-4 space-y-3">
        {rows.length === 0 && <div className="rounded-3xl border border-border bg-surface p-8 text-center text-sm text-muted-foreground">No {tab} comments.</div>}
        {rows.map((c) => (
          <div key={c.id} className="rounded-2xl border border-border bg-surface p-4 shadow-card">
            <div className="flex items-start gap-3">
              <div className="flex-1">
                <div className="text-sm font-semibold">{c.author_name} <span className="text-xs text-muted-foreground">on “{posts[c.post_id] ?? "post"}”</span></div>
                <p className="mt-1 whitespace-pre-wrap text-sm">{c.body}</p>
                <div className="mt-1 text-[11px] text-muted-foreground">{new Date(c.created_at).toLocaleString()}</div>
              </div>
              <div className="flex gap-1">
                {!c.approved && (
                  <button onClick={async () => { await supabase.from("comments").update({ approved: true }).eq("id", c.id); load(); }}
                    title="Approve" className="grid h-8 w-8 place-items-center rounded-full bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"><Check className="h-4 w-4" /></button>
                )}
                {c.approved && (
                  <button onClick={async () => { await supabase.from("comments").update({ approved: false }).eq("id", c.id); load(); }}
                    title="Unapprove" className="grid h-8 w-8 place-items-center rounded-full bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30"><EyeOff className="h-4 w-4" /></button>
                )}
                <button onClick={async () => { if (confirm("Delete comment?")) { await supabase.from("comments").delete().eq("id", c.id); load(); } }}
                  title="Delete" className="grid h-8 w-8 place-items-center rounded-full bg-destructive/20 text-destructive hover:bg-destructive/30"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
