import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Play, Bell, Wifi, Search } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { fetchChannels, type Channel } from "@/lib/m3u";
import { supabase } from "@/integrations/supabase/client";

type RailPost = {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  cover_image: string | null;
  published_at: string | null;
  created_at: string;
  categories: { slug: string; name: string } | null;
};

const RAILS: { title: string; slug: string; variant: "poster" | "wide" }[] = [
  { title: "New Shows", slug: "new-shows", variant: "wide" },
  { title: "Top Action Movies", slug: "top-action-movies", variant: "poster" },
  { title: "Latest Movies", slug: "latest-movies", variant: "poster" },
  { title: "Latest Web Series", slug: "latest-web-series", variant: "poster" },
];

const postsQuery = {
  queryKey: ["home-posts"],
  queryFn: async (): Promise<RailPost[]> => {
    const { data, error } = await supabase
      .from("posts")
      .select("id,title,slug,excerpt,cover_image,published_at,created_at,categories(slug,name)")
      .eq("published", true)
      .order("published_at", { ascending: false, nullsFirst: false })
      .limit(80);
    if (error) throw error;
    return (data ?? []) as unknown as RailPost[];
  },
  staleTime: 60 * 1000,
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Anime Cartoon — Live TV, Movies, Series & Anime" },
      { name: "description", content: "Stream live TV, movies, web series and new shows. Free 24/7." },
    ],
  }),
  loader: () => fetchChannels(),
  component: HomePage,
});

function HomePage() {
  const channels = Route.useLoaderData() as Channel[];
  const { data: posts = [] } = useQuery(postsQuery);

  const trendingPost = posts[0];
  const trendingChannel =
    channels.find((c) => /little singham|chhota bheem/i.test(c.name)) ?? channels[0];

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl px-4 pt-3">
        <TopBar />
        {trendingPost ? (
          <TrendingHeroPost post={trendingPost} />
        ) : (
          <TrendingHero channel={trendingChannel} />
        )}
        <LiveButton count={channels.length} />

        {RAILS.map((r) => {
          const items = posts.filter((p) => p.categories?.slug === r.slug);
          return <PostRail key={r.slug} title={r.title} items={items} variant={r.variant} />;
        })}
      </div>
    </AppShell>
  );
}

function TopBar() {
  return (
    <div className="flex items-center justify-between pb-3">
      <Link to="/" className="flex items-center gap-2 rounded-xl bg-surface px-3 py-2">
        <span className="grid h-6 w-6 place-items-center rounded-full gradient-brand">
          <Play className="h-3 w-3 fill-current text-primary-foreground" />
        </span>
        <span className="text-sm font-bold">Anime Cartoon</span>
      </Link>
      <div className="flex items-center gap-2">
        <Link
          to="/search"
          aria-label="Search"
          className="grid h-10 w-10 place-items-center rounded-full bg-surface text-muted-foreground hover:text-foreground"
        >
          <Search className="h-4 w-4" />
        </Link>
        <button className="relative grid h-10 w-10 place-items-center rounded-full bg-surface">
          <Bell className="h-4 w-4" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-live" />
        </button>
        <div className="grid h-10 w-10 place-items-center rounded-full bg-surface text-sm font-bold">S</div>
      </div>
    </div>
  );
}

function TrendingHeroPost({ post }: { post: RailPost }) {
  return (
    <section className="relative overflow-hidden rounded-3xl border border-border bg-surface p-4 shadow-card">
      <div className="relative flex min-h-[320px] flex-col items-center justify-center gap-4">
        <span className="absolute right-2 top-2 rounded-full bg-orange-500 px-3 py-1 text-xs font-bold text-white">
          #1 Trending
        </span>
        {post.cover_image ? (
          <img
            src={post.cover_image}
            alt={post.title}
            className="h-52 w-40 rounded-2xl object-cover shadow-glow"
            onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
          />
        ) : (
          <div className="grid h-52 w-40 place-items-center rounded-2xl bg-background text-3xl font-bold">
            {post.title[0]}
          </div>
        )}
        <div className="text-center">
          <div className="text-base font-bold">{post.title}</div>
          {post.excerpt && (
            <div className="mt-1 line-clamp-2 max-w-sm text-xs text-muted-foreground">{post.excerpt}</div>
          )}
        </div>
        <Link
          to="/posts/$slug"
          params={{ slug: post.slug }}
          className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-orange-500 to-amber-400 px-8 py-3 text-sm font-bold text-white shadow-glow"
        >
          <Play className="h-4 w-4 fill-current" /> Watch Now
        </Link>
      </div>
    </section>
  );
}

function TrendingHero({ channel }: { channel?: Channel }) {
  if (!channel) return null;
  return (
    <section className="relative overflow-hidden rounded-3xl border border-border bg-surface p-4 shadow-card">
      <div className="relative flex min-h-[320px] flex-col items-center justify-center gap-4">
        <span className="absolute right-2 top-2 rounded-full bg-orange-500 px-3 py-1 text-xs font-bold text-white">
          #1 Trending
        </span>
        {channel.logo ? (
          <img
            src={channel.logo}
            alt={channel.name}
            className="h-52 w-40 rounded-2xl object-cover shadow-glow"
            onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
          />
        ) : (
          <div className="grid h-52 w-40 place-items-center rounded-2xl bg-background text-5xl font-bold">
            {channel.name[0]}
          </div>
        )}
        <Link
          to="/watch/$id"
          params={{ id: channel.id }}
          className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-orange-500 to-amber-400 px-8 py-3 text-sm font-bold text-white shadow-glow"
        >
          <Play className="h-4 w-4 fill-current" /> Watch Now
        </Link>
      </div>
    </section>
  );
}

function LiveButton({ count }: { count: number }) {
  return (
    <Link
      to="/live"
      className="mt-4 flex items-center gap-3 rounded-2xl gradient-live p-4 shadow-card"
    >
      <span className="grid h-11 w-11 place-items-center rounded-full bg-background/20 backdrop-blur">
        <Wifi className="h-5 w-5 text-live-foreground" />
      </span>
      <div className="flex-1">
        <div className="text-base font-bold text-live-foreground">Live TV</div>
        <div className="text-xs text-live-foreground/80">{count}+ channels · 24/7</div>
      </div>
      <span className="flex items-center gap-1.5 rounded-full bg-background/20 px-3 py-1 text-xs font-bold text-live-foreground">
        <span className="live-dot" /> LIVE
      </span>
    </Link>
  );
}

function PostRail({
  title,
  items,
  variant,
}: {
  title: string;
  items: RailPost[];
  variant: "poster" | "wide";
}) {
  if (!items.length) return null;
  return (
    <section className="mt-7">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-base font-bold">{title}</h2>
      </div>

      <div className="scrollbar-hide -mx-4 flex gap-3 overflow-x-auto px-4 pb-2">
        {items.map((p) =>
          variant === "poster" ? (
            <PosterPost key={p.id} post={p} />
          ) : (
            <WideCardPost key={p.id} post={p} />
          ),
        )}
      </div>
    </section>
  );
}

function PosterPost({ post }: { post: RailPost }) {
  return (
    <Link to="/posts/$slug" params={{ slug: post.slug }} className="w-28 shrink-0 sm:w-32">
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-surface shadow-card">
        {post.cover_image ? (
          <img
            src={post.cover_image}
            alt={post.title}
            loading="lazy"
            className="h-full w-full object-cover"
            onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
          />
        ) : (
          <div className="grid h-full w-full place-items-center text-2xl font-bold text-muted-foreground">
            {post.title[0]}
          </div>
        )}
        <span className="absolute right-1.5 top-1.5 rounded bg-background/70 px-1.5 py-0.5 text-[10px] font-bold backdrop-blur">
          HD
        </span>
      </div>
      <div className="mt-1.5 line-clamp-1 text-xs font-medium">{post.title}</div>
    </Link>
  );
}

function WideCardPost({ post }: { post: RailPost }) {
  return (
    <Link to="/posts/$slug" params={{ slug: post.slug }} className="w-44 shrink-0 sm:w-52">
      <div className="relative aspect-video overflow-hidden rounded-xl bg-surface shadow-card">
        {post.cover_image ? (
          <img
            src={post.cover_image}
            alt={post.title}
            loading="lazy"
            className="h-full w-full object-cover"
            onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
          />
        ) : (
          <div className="grid h-full w-full place-items-center text-2xl font-bold text-muted-foreground">
            {post.title[0]}
          </div>
        )}
        <span className="absolute inset-0 grid place-items-center">
          <span className="grid h-9 w-9 place-items-center rounded-full bg-background/60 backdrop-blur">
            <Play className="h-4 w-4 fill-current" />
          </span>
        </span>
      </div>
      <div className="mt-1.5 line-clamp-1 text-xs font-semibold">{post.title}</div>
      {post.categories?.name && (
        <div className="text-[10px] uppercase text-muted-foreground">{post.categories.name}</div>
      )}
    </Link>
  );
}
