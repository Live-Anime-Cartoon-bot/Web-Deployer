import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { completeVerification, startVerification } from "@/lib/verify";

type Search = { token?: string; returnTo?: string };

export const Route = createFileRoute("/verify")({
  head: () => ({
    meta: [
      { title: "Verify Access · Anime Cartoon" },
      { name: "description", content: "Quick verification to unlock streaming." },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): Search => ({
    token: typeof s.token === "string" ? s.token : undefined,
    returnTo: typeof s.returnTo === "string" ? s.returnTo : undefined,
  }),
  component: VerifyPage,
});

function VerifyPage() {
  const { token, returnTo } = Route.useSearch();
  const navigate = useNavigate();
  const [status, setStatus] = useState<"idle" | "redirecting" | "verifying" | "error">(
    "idle",
  );
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (token) {
      setStatus("verifying");
      const dest = completeVerification(token);
      if (dest) {
        // Use replace so user can't go back into verify
        window.location.replace(dest);
      } else {
        setStatus("error");
        setMessage(
          "This verification link is invalid or expired. Please request a fresh link.",
        );
      }
    }
  }, [token, navigate]);

  async function onUnlock() {
    setStatus("redirecting");
    try {
      await startVerification(returnTo || "/live");
    } catch (e) {
      setStatus("error");
      setMessage((e as Error).message);
    }
  }

  return (
    <div className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-md rounded-3xl border border-border bg-surface p-6 text-center shadow-glow">
        <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-brand/20 text-brand">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            className="h-7 w-7"
          >
            <path d="M12 2 4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6l-8-4z" />
            <path d="m9 12 2 2 4-4" />
          </svg>
        </div>
        <h1 className="text-xl font-bold">Verify to Continue</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          To support the server, please complete a quick verification. It only takes a few
          seconds and unlocks streaming for 12 hours.
        </p>

        {status === "verifying" && (
          <p className="mt-6 text-sm text-accent">Verifying token…</p>
        )}

        {status === "error" && (
          <div className="mt-6 space-y-3">
            <p className="text-sm text-live">{message}</p>
            <button
              onClick={onUnlock}
              className="w-full rounded-xl bg-gradient-to-r from-brand to-accent px-4 py-3 text-sm font-bold uppercase tracking-wide text-white shadow-glow"
            >
              Try again
            </button>
          </div>
        )}

        {!token && status === "idle" && (
          <button
            onClick={onUnlock}
            className="mt-6 w-full rounded-xl bg-gradient-to-r from-brand to-accent px-4 py-3 text-sm font-bold uppercase tracking-wide text-white shadow-glow"
          >
            Verify Now
          </button>
        )}

        {status === "redirecting" && (
          <p className="mt-6 text-sm text-muted-foreground">Opening verification link…</p>
        )}

        <ol className="mt-6 space-y-2 text-left text-xs text-muted-foreground">
          <li>1. Tap "Verify Now" — opens shrinkme.io in a new tab/window.</li>
          <li>2. Wait a few seconds and tap "Get Link" / "Continue".</li>
          <li>3. You'll return here automatically and streaming will unlock.</li>
        </ol>
      </div>
    </div>
  );
}
