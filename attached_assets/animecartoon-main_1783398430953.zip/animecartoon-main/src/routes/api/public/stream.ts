import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

// Proxies HLS playlists and segments to bypass CORS / mixed-content.
// For .m3u8 responses, rewrites every URL inside to route back through this proxy.

const PROXY_PATH = "/api/public/stream";

function rewritePlaylist(text: string, baseUrl: string): string {
  const base = new URL(baseUrl);
  return text
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;

      // Rewrite URI="..." attributes (EXT-X-KEY, EXT-X-MAP, etc.)
      let out = line.replace(/URI="([^"]+)"/g, (_m, uri) => {
        const abs = new URL(uri, base).toString();
        return `URI="${PROXY_PATH}?u=${encodeURIComponent(abs)}"`;
      });

      // Strip CODECS attribute from EXT-X-STREAM-INF so players don't
      // pre-reject variants via MediaSource.isTypeSupported. The browser
      // will still fail cleanly if it truly can't decode.
      if (trimmed.startsWith("#EXT-X-STREAM-INF")) {
        out = out.replace(/,?CODECS="[^"]*"/g, "");
      }

      if (trimmed.startsWith("#")) return out;

      // Plain URL line (segment or sub-playlist)
      const abs = new URL(trimmed, base).toString();
      return `${PROXY_PATH}?u=${encodeURIComponent(abs)}`;
    })
    .join("\n");
}

async function proxy(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const target = url.searchParams.get("u");
  if (!target) return new Response("missing u", { status: 400 });

  let targetUrl: URL;
  try {
    targetUrl = new URL(target);
  } catch {
    return new Response("bad url", { status: 400 });
  }
  if (!/^https?:$/.test(targetUrl.protocol)) {
    return new Response("bad protocol", { status: 400 });
  }

  // Forward Range header for video segments
  const headers: HeadersInit = {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    Referer: `${targetUrl.protocol}//${targetUrl.host}/`,
  };
  const range = request.headers.get("range");
  if (range) (headers as Record<string, string>).Range = range;

  const upstream = await fetch(targetUrl.toString(), {
    method: request.method,
    headers,
    redirect: "follow",
  });

  const ct = upstream.headers.get("content-type") ?? "";
  const isPlaylist =
    /mpegurl/i.test(ct) ||
    targetUrl.pathname.endsWith(".m3u8") ||
    targetUrl.pathname.endsWith(".m3u");

  const outHeaders = new Headers();
  outHeaders.set("Access-Control-Allow-Origin", "*");
  outHeaders.set("Access-Control-Allow-Headers", "*");
  outHeaders.set("Access-Control-Expose-Headers", "*");

  if (isPlaylist) {
    const text = await upstream.text();
    const rewritten = rewritePlaylist(text, upstream.url || targetUrl.toString());
    outHeaders.set("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8");
    outHeaders.set("Cache-Control", "no-store");
    return new Response(rewritten, { status: upstream.status, headers: outHeaders });
  }

  // Pass through binary content
  const passThrough = ["content-type", "content-length", "content-range", "accept-ranges", "cache-control"];
  for (const h of passThrough) {
    const v = upstream.headers.get(h);
    if (v) outHeaders.set(h, v);
  }
  if (!outHeaders.has("content-type")) {
    outHeaders.set("Content-Type", "application/octet-stream");
  }
  return new Response(upstream.body, { status: upstream.status, headers: outHeaders });
}

export const Route = createFileRoute("/api/public/stream")({
  server: {
    handlers: {
      GET: ({ request }) => proxy(request),
      HEAD: ({ request }) => proxy(request),
      OPTIONS: () =>
        new Response(null, {
          status: 204,
          headers: {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
            "Access-Control-Allow-Headers": "*",
          },
        }),
    },
  },
});
