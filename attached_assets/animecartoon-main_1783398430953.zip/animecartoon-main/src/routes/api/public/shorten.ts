import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/shorten")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const target = url.searchParams.get("url");
        if (!target) {
          return Response.json({ error: "Missing url" }, { status: 400 });
        }
        const apiToken = process.env.SHRINKME_API_TOKEN;
        if (!apiToken) {
          return Response.json({ error: "Shortener not configured" }, { status: 500 });
        }
        try {
          const api = `https://shrinkme.io/api?api=${apiToken}&url=${encodeURIComponent(
            target,
          )}&format=json`;
          const res = await fetch(api);
          const data = (await res.json()) as {
            status?: string;
            shortenedUrl?: string;
            message?: string;
          };
          if (data.status === "success" && data.shortenedUrl) {
            return Response.json({ short: data.shortenedUrl });
          }
          return Response.json(
            { error: data.message || "Shortener failed", short: target },
            { status: 502 },
          );
        } catch (e) {
          return Response.json(
            { error: (e as Error).message, short: target },
            { status: 502 },
          );
        }
      },
    },
  },
});
