import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { channelsToM3U, fetchPublicPlaylistChannels } from "@/lib/m3u";

export const Route = createFileRoute("/api/public/playlist")({
  server: {
    handlers: {
      GET: async () => {
        const channels = await fetchPublicPlaylistChannels();
        return new Response(channelsToM3U(channels), {
          headers: {
            "Content-Type": "application/vnd.apple.mpegurl; charset=utf-8",
            "Cache-Control": "public, max-age=180",
            "Access-Control-Allow-Origin": "*",
          },
        });
      },
    },
  },
});
