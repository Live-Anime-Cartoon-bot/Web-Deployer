import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { HlsPlayer } from "@/components/HlsPlayer";
import { fetchChannels, type Channel } from "@/lib/m3u";
import { hasValidToken, startVerification, tokenExpiresAt } from "@/lib/verify";

export const Route = createFileRoute("/watch/$id")({
  head: ({ params }) => ({
    meta: [
      { title: `Watching ${params.id} · Anime Cartoon` },
      { name: "description", content: "Live streaming on Anime Cartoon." },
    ],
  }),
  loader: () => fetchChannels(),
  component: WatchPage,
  notFoundComponent: () => (
    <div className="p-8 text-center text-muted-foreground">Channel not found.</div>
  ),
});

function WatchPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const channels = Route.useLoaderData() as Channel[];
  const channel = channels.find((c) => c.id === id);

  const [unlocked, setUnlocked] = useState(false);
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [working, setWorking] = useState(false);

  useEffect(() => {
    setUnlocked(hasValidToken());
    setExpiresAt(tokenExpiresAt());
  }, []);

  if (!channel) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-12 text-center">
        <h1 className="text-xl font-semibold">Channel not found</h1>
        <Link to="/live" className="mt-4 inline-block text-accent underline">
          Back to Live TV
        </Link>
      </div>
    );
  }

  async function onUnlock() {
    setWorking(true);
    try {
      await startVerification(window.location.pathname);
    } finally {
      setWorking(false);
    }
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-xl">
        <Link
          to="/live"
          aria-label="Back"
          className="grid h-9 w-9 place-items-center rounded-full bg-surface hover:bg-surface-2"
        >
          <ArrowLeft className="h-4 w-4" />
        </Link>
        <div className="flex min-w-0 flex-1 items-center gap-2">
          <span className="live-dot shrink-0" />
          <h1 className="truncate text-sm font-semibold uppercase tracking-wide">{channel.name}</h1>
        </div>
        <span className="flex items-center gap-1 text-xs font-bold uppercase text-live">
          Live
        </span>
      </header>

      <div className="mx-auto max-w-5xl px-3 pt-3">
        {unlocked ? (
          <>
            <HlsPlayer src={channel.url} poster={channel.logo} />
            <p className="mt-3 text-center text-xs text-muted-foreground">
              Access unlocked
              {expiresAt
                ? ` · expires ${new Date(expiresAt).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}`
                : ""}
            </p>
          </>
        ) : (
          <div className="relative overflow-hidden rounded-3xl border border-border bg-surface p-6 text-center shadow-glow">
            {channel.logo && (
              <img
                src={channel.logo}
                alt=""
                aria-hidden
                className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-10 blur-2xl"
              />
            )}
            <div className="relative">
              <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-brand/20 text-brand">
                <ShieldCheck className="h-7 w-7" />
              </div>
              <h2 className="text-lg font-bold">Verify to Watch</h2>
              <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
                Complete a quick verification (it takes a few seconds) to unlock{" "}
                <span className="font-semibold text-foreground">{channel.name}</span> and
                every channel for the next 12 hours.
              </p>
              <button
                onClick={onUnlock}
                disabled={working}
                className="mt-5 w-full rounded-xl bg-gradient-to-r from-brand to-accent px-4 py-3 text-sm font-bold uppercase tracking-wide text-white shadow-glow disabled:opacity-60"
              >
                {working ? "Opening verification…" : "Verify & Watch Now"}
              </button>
              <p className="mt-3 text-[11px] text-muted-foreground">
                You'll be redirected via shrinkme.io and brought back automatically.
              </p>
            </div>
          </div>
        )}
      </div>


      <div className="mx-auto max-w-6xl px-4 pt-6 pb-24">
        <h2 className="mb-3 text-xs font-bold uppercase tracking-widest text-muted-foreground">
          All channels
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {channels.map((ch) => (
            <button
              key={ch.id}
              onClick={() => navigate({ to: "/watch/$id", params: { id: ch.id } })}
              className={`flex flex-col items-center gap-2 rounded-2xl border p-3 text-left transition ${
                ch.id === channel.id
                  ? "border-brand bg-surface-2 shadow-glow"
                  : "border-border bg-surface hover:border-brand hover:bg-surface-2"
              }`}
            >
              <div className="relative h-14 w-14 overflow-hidden rounded-full bg-background ring-2 ring-border">
                {ch.logo ? (
                  <img
                    src={ch.logo}
                    alt={ch.name}
                    loading="lazy"
                    className="h-full w-full object-cover"
                    onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
                  />
                ) : (
                  <div className="grid h-full w-full place-items-center text-lg font-bold text-muted-foreground">
                    {ch.name[0]}
                  </div>
                )}
              </div>
              <div className="line-clamp-2 text-center text-[10px] font-semibold uppercase">
                {ch.name}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// Suppress unused warning for typed-route helper file
export type _C = Channel;
