import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Search, X } from "lucide-react";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";

type SearchPost = {
  id: string;
  title: string;
  slug: string;
  cover_image: string | null;
  categories: { slug: string; name: string } | null;
};

const searchSchema = z.object({
  q: fallback(z.string().max(100), "").default(""),
});

function searchPostsQueryOptions(q: string) {
  const term = q.trim().slice(0, 100);
  return queryOptions({
    queryKey: ["search-posts", term],
    queryFn: async (): Promise<SearchPost[]> => {
      if (!term) return [];
      const pattern = `%${term.replace(/[%_]/g, "\\$&")}%`;
      const { data, error } = await supabase
        .from("posts")
        .select("id,title,slug,cover_image,categories(slug,name)")
        .eq("published", true)
        .or(`title.ilike.${pattern},slug.ilike.${pattern}`)
        .order("published_at", { ascending: false, nullsFirst: false })
        .limit(50);
      if (error) throw error;
      return (data ?? []) as unknown as SearchPost[];
    },
    staleTime: 30 * 1000,
  });
}

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Search · Anime Cartoon" },
      { name: "description", content: "Search movies, web series, anime and posts on Anime Cartoon." },
      { property: "og:title", content: "Search · Anime Cartoon" },
      { property: "og:description", content: "Search movies, web series, anime and posts on Anime Cartoon." },
    ],
  }),
  validateSearch: zodValidator(searchSchema),
  loaderDeps: ({ search: { q } }) => ({ q }),
  loader: ({ context, deps }) => context.queryClient.ensureQueryData(searchPostsQueryOptions(deps.q)),
  component: SearchPage,
  errorComponent: ({ error, reset }) => (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold text-foreground">Search failed</h1>
        <p className="mt-2 text-sm text-muted-foreground">{(error as Error).message}</p>
        <button
          onClick={reset}
          className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          Try again
        </button>
      </div>
    </div>
  ),
  notFoundComponent: () => (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold text-foreground">Not found</h1>
        <Link to="/" className="mt-4 inline-block text-sm text-accent hover:underline">
          ← Back to home
        </Link>
      </div>
    </div>
  ),
});

function SearchPage() {
  const { q } = Route.useSearch();
  const navigate = useNavigate({ from: "/search" });
  const [input, setInput] = useState(q);
  const { data: posts = [] } = useSuspenseQuery(searchPostsQueryOptions(q));

  useEffect(() => {
    const t = setTimeout(() => {
      navigate({ search: { q: input.trim() } });
    }, 250);
    return () => clearTimeout(t);
  }, [input, navigate]);

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl px-4 pt-4">
        <div className="flex items-center gap-3">
          <Link
            to="/"
            aria-label="Back"
            className="grid h-9 w-9 place-items-center rounded-full bg-surface text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <h1 className="text-xl font-bold leading-tight">Search</h1>
            <p className="text-xs text-muted-foreground">Movies, series & anime</p>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            navigate({ search: { q: input.trim() } });
          }}
          className="mt-4 flex items-center gap-2 rounded-full border border-border bg-surface px-4 py-2.5 focus-within:border-brand"
        >
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Search shows, movies, anime…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            autoFocus
          />
          {input && (
            <button
              type="button"
              onClick={() => setInput("")}
              aria-label="Clear search"
              className="grid h-6 w-6 place-items-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </form>

        {q ? (
          <div className="mt-6">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-muted-foreground">
                Results for “{q}”
              </h2>
              <span className="text-xs text-muted-foreground">{posts.length} found</span>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
            {posts.length === 0 && (
              <div className="mt-12 text-center">
                <p className="text-sm text-muted-foreground">No shows match “{q}”.</p>
                <p className="mt-1 text-xs text-muted-foreground">Try a different title.</p>
              </div>
            )}
          </div>
        ) : (
          <div className="mt-12 text-center">
            <p className="text-sm text-muted-foreground">Type a title to find movies, series or anime.</p>
          </div>
        )}
      </div>
    </AppShell>
  );
}

function PostCard({ post }: { post: SearchPost }) {
  return (
    <Link to="/posts/$slug" params={{ slug: post.slug }} className="group">
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl bg-surface shadow-card">
        {post.cover_image ? (
          <img
            src={post.cover_image}
            alt={post.title}
            loading="lazy"
            className="h-full w-full object-cover transition group-hover:scale-105"
            onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
          />
        ) : (
          <div className="grid h-full w-full place-items-center text-2xl font-bold text-muted-foreground">
            {post.title[0]}
          </div>
        )}
        <span className="absolute right-1.5 top-1.5 rounded bg-background/70 px-1.5 py-0.5 text-[10px] font-bold backdrop-blur">
          HD
        </span>
      </div>
      <div className="mt-1.5 line-clamp-1 text-xs font-medium">{post.title}</div>
      {post.categories?.name && (
        <div className="text-[10px] uppercase text-muted-foreground">{post.categories.name}</div>
      )}
    </Link>
  );
}
