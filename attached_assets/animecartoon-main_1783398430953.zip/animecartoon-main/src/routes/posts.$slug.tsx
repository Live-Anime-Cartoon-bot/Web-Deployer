import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Download, Play, Calendar, Clock, HardDrive, Languages, Film, User, ListVideo } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth-hooks";

type PostMeta = {
  series_name?: string;
  release_date?: string;
  total_parts?: string;
  duration?: string;
  file_size?: string;
  languages?: string;
  video_quality?: string;
  encoded_by?: string;
};

type Episode = {
  label: string;
  image?: string;
  download_url?: string;
  watch_url?: string;
};

type Post = {
  id: string;
  title: string;
  slug: string;
  html: string;
  cover_image: string | null;
  published_at: string | null;
  tags: string[];
  meta: PostMeta;
  episodes: Episode[];
};

type Comment = { id: string; author_name: string; body: string; created_at: string };

export const Route = createFileRoute("/posts/$slug")({
  head: () => ({ meta: [{ title: "Post · Anime Cartoon" }] }),
  component: PostPage,
});

function PostPage() {
  const { slug } = useParams({ from: "/posts/$slug" });
  const [post, setPost] = useState<Post | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [episodeIdx, setEpisodeIdx] = useState(0);
  const { session } = useSession();
  const [body, setBody] = useState("");
  const [posting, setPosting] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    supabase.from("posts").select("*").eq("slug", slug).eq("published", true).maybeSingle()
      .then(({ data }) => {
        if (!data) setNotFound(true);
        else {
          const d = data as unknown as Post;
          setPost({
            ...d,
            meta: (d.meta ?? {}) as PostMeta,
            episodes: Array.isArray(d.episodes) ? d.episodes : [],
          });
        }
      });
  }, [slug]);

  useEffect(() => {
    if (!post) return;
    supabase.from("comments").select("id,author_name,body,created_at")
      .eq("post_id", post.id).eq("approved", true).order("created_at", { ascending: false })
      .then(({ data }) => setComments((data ?? []) as Comment[]));
  }, [post]);

  async function submitComment(e: React.FormEvent) {
    e.preventDefault();
    if (!post || !session) return;
    setPosting(true); setMsg(null);
    const { error } = await supabase.from("comments").insert({
      post_id: post.id,
      user_id: session.user.id,
      author_name: session.user.email ?? "Anonymous",
      body,
    });
    setPosting(false);
    if (error) setMsg(error.message);
    else { setBody(""); setMsg("Comment submitted — awaiting moderation."); }
  }

  if (notFound) return (
    <AppShell><div className="mx-auto max-w-2xl px-4 py-16 text-center">
      <h1 className="text-2xl font-bold">Post not found</h1>
      <Link to="/" className="mt-4 inline-block text-sm text-accent hover:underline">← Back to home</Link>
    </div></AppShell>
  );


  if (!post) return <AppShell><div className="mx-auto max-w-2xl px-4 py-16 text-center text-muted-foreground">Loading…</div></AppShell>;

  const meta = post.meta ?? {};
  const metaRows: [React.ReactNode, string, string | undefined][] = [
    [<Film className="h-4 w-4" />, "Series Name", meta.series_name],
    [<Calendar className="h-4 w-4" />, "Release Date", meta.release_date],
    [<ListVideo className="h-4 w-4" />, "Total Parts", meta.total_parts],
    [<Clock className="h-4 w-4" />, "Duration", meta.duration],
    [<HardDrive className="h-4 w-4" />, "File Size", meta.file_size],
    [<Languages className="h-4 w-4" />, "Languages", meta.languages],
    [<Film className="h-4 w-4" />, "Video Quality", meta.video_quality],
    [<User className="h-4 w-4" />, "Encoded By", meta.encoded_by],
  ];
  const hasMeta = metaRows.some(([, , v]) => v);
  const ep = post.episodes[episodeIdx];

  return (
    <AppShell>
      <article className="mx-auto max-w-3xl px-4 pt-6 pb-16">
        <Link to="/" className="text-xs text-muted-foreground hover:text-foreground">← Back to home</Link>
        <h1 className="mt-3 text-2xl font-bold sm:text-3xl">{post.title}</h1>
        {post.published_at && <div className="mt-1 text-xs text-muted-foreground">{new Date(post.published_at).toLocaleDateString()}</div>}
        {post.cover_image && <img src={post.cover_image} alt={post.title} className="mt-4 w-full rounded-2xl border border-border" />}

        {hasMeta && (
          <section className="mt-6 overflow-hidden rounded-2xl border border-border bg-surface">
            <table className="w-full text-sm">
              <tbody>
                {metaRows.filter(([, , v]) => v).map(([icon, label, value], i) => (
                  <tr key={label} className={i > 0 ? "border-t border-border/60" : ""}>
                    <td className="w-1/3 px-4 py-3 align-top text-muted-foreground">
                      <span className="flex items-center gap-2"><span className="text-brand">{icon}</span>{label}</span>
                    </td>
                    <td className="px-4 py-3 font-medium">{value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        )}

        {post.episodes.length > 0 && (
          <>
            <section className="mt-6 flex items-center gap-3 rounded-2xl border border-border bg-surface p-4">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Select Episode:</span>
              <select
                value={episodeIdx}
                onChange={(e) => setEpisodeIdx(Number(e.target.value))}
                className="flex-1 rounded-xl border border-border bg-background px-4 py-2 text-sm font-semibold outline-none focus:border-brand"
              >
                {post.episodes.map((e, i) => (
                  <option key={i} value={i}>{e.label || `Episode ${i + 1}`}</option>
                ))}
              </select>
            </section>

            <section className="mt-6">
              <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-orange-400 border-b border-border pb-2">Download Links</h2>
              <div className="rounded-2xl border border-border bg-surface p-4">
                {ep?.image && (
                  <img src={ep.image} alt={ep.label} className="mb-4 w-full rounded-xl" />
                )}
                <div className="flex flex-col gap-2">
                  {ep?.watch_url && (
                    <a href={ep.watch_url} target="_blank" rel="noreferrer noopener"
                      className="flex items-center justify-center gap-2 rounded-xl bg-blue-500 py-3 text-sm font-bold text-white hover:bg-blue-600">
                      <Play className="h-4 w-4 fill-current" /> Watch Online
                    </a>
                  )}
                  {ep?.download_url && (
                    <a href={ep.download_url} target="_blank" rel="noreferrer noopener"
                      className="flex items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white hover:bg-emerald-600">
                      <Download className="h-4 w-4" /> Download Episode
                    </a>
                  )}
                  {!ep?.download_url && !ep?.watch_url && (
                    <p className="py-3 text-center text-xs text-muted-foreground">No links added for this episode.</p>
                  )}
                </div>
              </div>
            </section>
          </>
        )}

        {post.html && (
          <div className="prose prose-invert mt-8 max-w-none" dangerouslySetInnerHTML={{ __html: post.html }} />
        )}

        <section className="mt-12 border-t border-border pt-6">
          <h2 className="text-lg font-semibold">Comments ({comments.length})</h2>
          {session ? (
            <form onSubmit={submitComment} className="mt-4 space-y-2">
              <textarea required value={body} onChange={(e) => setBody(e.target.value)} placeholder="Share your thoughts…"
                className="h-24 w-full rounded-xl border border-border bg-surface p-3 text-sm outline-none focus:border-brand" />
              <div className="flex items-center gap-3">
                <button disabled={posting || !body.trim()} className="rounded-full gradient-brand px-5 py-2 text-xs font-semibold text-primary-foreground shadow-glow disabled:opacity-60">
                  {posting ? "Posting…" : "Post comment"}
                </button>
                {msg && <span className="text-xs text-muted-foreground">{msg}</span>}
              </div>
            </form>
          ) : (
            <p className="mt-4 text-sm text-muted-foreground">
              <Link to="/auth" className="text-accent hover:underline">Sign in</Link> to comment.
            </p>
          )}
          <ul className="mt-6 space-y-3">
            {comments.map((c) => (
              <li key={c.id} className="rounded-xl border border-border bg-surface p-4">
                <div className="text-sm font-semibold">{c.author_name}</div>
                <p className="mt-1 whitespace-pre-wrap text-sm">{c.body}</p>
                <div className="mt-1 text-[11px] text-muted-foreground">{new Date(c.created_at).toLocaleString()}</div>
              </li>
            ))}
            {comments.length === 0 && <p className="text-sm text-muted-foreground">Be the first to comment.</p>}
          </ul>
        </section>
      </article>
    </AppShell>
  );
}
