import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Tv, Search, Bookmark } from "lucide-react";

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const onAdmin = pathname.startsWith("/admin");

  return (
    <div className="relative min-h-screen pb-24">
      <main>{children}</main>

      {!onAdmin && (
        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/80 backdrop-blur-xl">
          <div className="mx-auto flex max-w-6xl items-center justify-around px-4 py-2">
            <NavItem to="/" icon={<Home className="h-5 w-5" />} label="Home" active={pathname === "/"} />
            <NavItem to="/search" icon={<Search className="h-5 w-5" />} label="Search" active={pathname === "/search"} />
            <NavItem to="/live" icon={<Tv className="h-5 w-5" />} label="Live TV" active={pathname.startsWith("/live") || pathname.startsWith("/watch")} />
            <NavItem to="/" icon={<Bookmark className="h-5 w-5" />} label="Watch List" active={false} />
          </div>
        </nav>
      )}
    </div>
  );
}

function NavItem({
  to,
  icon,
  label,
  active,
}: {
  to: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={`flex flex-col items-center gap-0.5 px-3 py-1 text-xs ${
        active ? "text-[hsl(var(--live,25_95%_55%))] text-orange-400" : "text-muted-foreground"
      }`}
    >
      <span className="grid h-7 w-7 place-items-center">{icon}</span>
      <span className={active ? "font-semibold" : ""}>{label}</span>
    </Link>
  );
}
