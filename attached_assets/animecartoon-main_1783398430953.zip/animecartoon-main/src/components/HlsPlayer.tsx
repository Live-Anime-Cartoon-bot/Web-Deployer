import { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import type mpegtsType from "mpegts.js";
import { proxiedStreamUrl } from "@/lib/stream-url";

interface Props {
  src: string;
  poster?: string;
  autoPlay?: boolean;
  className?: string;
}

const UNAVAILABLE_MESSAGE = "स्ट्रीम उपलब्ध नहीं है। कृपया अन्य चैनल आज़माएँ।";
const RETRYING_MESSAGE = "Stream reconnecting…";

function looksLikeRawTs(url: string): boolean {
  try {
    const u = new URL(url);
    const p = u.pathname.toLowerCase();
    return p.endsWith(".ts") || p.endsWith(".mts") || p.endsWith(".m2ts");
  } catch {
    return /\.ts(\?|$)/i.test(url);
  }
}

async function shouldUseMpegTs(src: string, proxied: string): Promise<boolean> {
  if (looksLikeRawTs(src)) return true;

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 4_000);
  try {
    const res = await fetch(proxied, {
      method: "HEAD",
      cache: "no-store",
      signal: controller.signal,
    });
    const contentType = res.headers.get("content-type")?.toLowerCase() ?? "";
    if (contentType.includes("video/mp2t") || contentType.includes("mpegts")) return true;
    if (contentType.includes("mpegurl")) return false;
  } catch {
    // fall back to HLS; the player will show retry/unavailable if the stream is down
  } finally {
    window.clearTimeout(timeout);
  }

  return false;
}

export function HlsPlayer({ src, poster, autoPlay = true, className }: Props) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [retryNonce, setRetryNonce] = useState(0);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    setError(null);

    const proxied = proxiedStreamUrl(src);
    let hls: Hls | null = null;
    let tsPlayer: ReturnType<typeof mpegtsType.createPlayer> | null = null;
    let cancelled = false;
    let recoveryAttempts = 0;
    const recoveryTimers: number[] = [];

    const scheduleRecovery = (fn: () => void) => {
      if (recoveryAttempts >= 8) {
        setError(UNAVAILABLE_MESSAGE);
        return;
      }
      recoveryAttempts += 1;
      setError(RETRYING_MESSAGE);
      const timer = window.setTimeout(() => {
        if (!cancelled) fn();
      }, 700 * recoveryAttempts);
      recoveryTimers.push(timer);
    };

    (async () => {
      const isRawTs = await shouldUseMpegTs(src, proxied);
      if (cancelled) return;

      if (isRawTs) {
        const mod = await import("mpegts.js");
        const mpegts = mod.default;
        if (cancelled) return;
        if (mpegts.getFeatureList().mseLivePlayback) {
          tsPlayer = mpegts.createPlayer(
            { type: "mpegts", isLive: true, url: proxied },
            {
              enableWorker: false,
              enableStashBuffer: false,
              stashInitialSize: 128,
              liveBufferLatencyChasing: true,
            },
          );
          tsPlayer.attachMediaElement(video);
          tsPlayer.load();
          tsPlayer.on(mpegts.Events.MEDIA_INFO, () => {
            recoveryAttempts = 0;
            setError(null);
          });
          tsPlayer.on(mpegts.Events.ERROR, () => {
            scheduleRecovery(() => {
              try {
                tsPlayer?.unload();
                tsPlayer?.load();
                if (autoPlay) void tsPlayer?.play();
              } catch {
                setError(UNAVAILABLE_MESSAGE);
              }
            });
          });
          if (autoPlay) {
            const p = tsPlayer.play();
            if (p && typeof (p as Promise<void>).catch === "function") {
              (p as Promise<void>).catch(() => {});
            }
          }
          return;
        }
        setError("Your browser cannot play this stream.");
        return;
      }

      if (Hls.isSupported()) {
        hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          backBufferLength: 30,
          maxBufferLength: 20,
          maxMaxBufferLength: 30,
          liveSyncDurationCount: 2,
          liveMaxLatencyDurationCount: 6,
          manifestLoadingMaxRetry: 6,
          levelLoadingMaxRetry: 6,
          fragLoadingMaxRetry: 8,
          manifestLoadingRetryDelay: 800,
          levelLoadingRetryDelay: 800,
          fragLoadingRetryDelay: 800,
          fragLoadingMaxRetryTimeout: 8_000,
        });
        hls.loadSource(proxied);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          recoveryAttempts = 0;
          setError(null);
        });
        hls.on(Hls.Events.FRAG_BUFFERED, () => {
          recoveryAttempts = 0;
          setError(null);
        });
        hls.on(Hls.Events.ERROR, (_e, data) => {
          if (!data.fatal || cancelled) return;

          if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
            scheduleRecovery(() => {
              hls?.stopLoad();
              hls?.loadSource(proxiedStreamUrl(src));
              hls?.startLoad(-1);
            });
            return;
          }

          if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
            scheduleRecovery(() => hls?.recoverMediaError());
            return;
          }

          setError(UNAVAILABLE_MESSAGE);
        });
        if (autoPlay) {
          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            void video.play().catch(() => {});
          });
        }
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = proxied;
        if (autoPlay) void video.play().catch(() => {});
      } else {
        setError("Your browser cannot play this stream.");
      }
    })();

    return () => {
      cancelled = true;
      recoveryTimers.forEach((timer) => window.clearTimeout(timer));
      try {
        hls?.destroy();
      } catch {
        /* noop */
      }
      try {
        tsPlayer?.pause();
        tsPlayer?.unload();
        tsPlayer?.detachMediaElement();
        tsPlayer?.destroy();
      } catch {
        /* noop */
      }
      video.removeAttribute("src");
      video.load();
    };
  }, [src, autoPlay, retryNonce]);

  return (
    <div className={`relative aspect-video w-full overflow-hidden rounded-2xl bg-black ${className ?? ""}`}>
      <video
        ref={videoRef}
        poster={poster}
        controls
        playsInline
        className="h-full w-full bg-black"
      />
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/75 px-4 text-center text-sm text-foreground">
          <span>{error}</span>
          {error === UNAVAILABLE_MESSAGE && (
            <button
              type="button"
              onClick={() => setRetryNonce((value) => value + 1)}
              className="rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground"
            >
              Retry Stream
            </button>
          )}
        </div>
      )}
    </div>
  );
}
