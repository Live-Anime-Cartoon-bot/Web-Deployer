document.addEventListener('DOMContentLoaded', function() {
    // PlayList Button
    const PlayListButton = document.getElementById('PlayListButton');
    if (PlayListButton) {
        PlayListButton.addEventListener('click', function() {
            const modal = document.getElementById('playlistModal');
            if (modal) {
                modal.classList.remove('hidden');
            }
            const urlInput = document.getElementById('playlistUrl');
            if (urlInput) {
                urlInput.value = window.location.origin + window.location.pathname.replace(/index\.php$/, '') + 'app/playlist.php';
            }
        });
    }

    // Close playlist modal
    const closePlaylistBtn = document.querySelector('#playlistModal button[id*="close"], #playlistModal #closeModal');
    if (closePlaylistBtn) {
        closePlaylistBtn.addEventListener('click', closePlaylistModal);
    }

    // Close modals on background click
    document.addEventListener('click', function(e) {
        const modals = ['playlistModal'];
        modals.forEach(id => {
            const modal = document.getElementById(id);
            if (modal && e.target === modal) {
                modal.classList.add('hidden');
            }
        });
    });
});

function closePlaylistModal() {
    const modal = document.getElementById('playlistModal');
    if (modal) modal.classList.add('hidden');
}

function copyPlaylistUrl() {
    const urlInput = document.getElementById('playlistUrl');
    if (urlInput) {
        urlInput.select();
        urlInput.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(urlInput.value).then(() => {
            const btn = urlInput.nextElementSibling;
            if (btn) {
                const original = btn.innerHTML;
                btn.innerHTML = '<span class="iconify" data-icon="mdi:check"></span>';
                setTimeout(() => btn.innerHTML = original, 1500);
            }
        });
    }
}
