<?php
// Admin Panel - Protected by Password
// Password: Little Singham

session_start();

$ADMIN_PASSWORD = "Little Singham";

function encrypt_data($data, $key)
{
  $key = intval($key);
  $encrypted = '';
  for ($i = 0; $i < strlen($data); $i++) {
    $encrypted .= chr(ord($data[$i]) + $key);
  }
  return base64_encode($encrypted);
}

function decrypt_data($e_data, $key)
{
  $key = intval($key);
  $encrypted = base64_decode($e_data);
  $decrypted = '';
  for ($i = 0; $i < strlen($encrypted); $i++) {
    $decrypted .= chr(ord($encrypted[$i]) - $key);
  }
  return $decrypted;
}

function send_jio_otp($mobile)
{
  $api = 'https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/send';
  $headers = array('appname: RJIL_JioTV', 'os: android', 'devicetype: phone', 'content-type: application/json', 'user-agent: okhttp/3.14.9');
  $payload = array('number' => base64_encode('+91' . $mobile));
  $ch = curl_init($api);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_TIMEOUT, 10);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  $resp = curl_exec($ch);
  $info = curl_getinfo($ch);
  curl_close($ch);
  $data = @json_decode($resp, true);
  if ($info['http_code'] == 204) {
    return ["status" => "success", "message" => "OTP Sent Successfully"];
  }
  return ["status" => "error", "message" => $data['message'] ?? "Error code " . $info['http_code']];
}

function verify_jio_otp($mobile, $otp)
{
  $DATA_FOLDER = "../assets/data";
  $u_name = encrypt_data($mobile, "TS-JIOTV");
  $api = 'https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/verify';
  $headers = [
    'appname: RJIL_JioTV', 'os: android', 'devicetype: phone',
    'content-type: application/json', 'user-agent: okhttp/3.14.9'
  ];
  $payload = [
    'number' => base64_encode('+91' . $mobile),
    'otp' => $otp,
    'deviceInfo' => [
      'consumptionDeviceName' => 'RMX1945',
      'info' => [
        'type' => 'android',
        'platform' => ['name' => 'RMX1945'],
        'androidId' => 'tsjiotvweb123456'
      ]
    ]
  ];
  $ch = curl_init($api);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_TIMEOUT, 10);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  $resp = curl_exec($ch);
  $info = curl_getinfo($ch);
  curl_close($ch);
  $data = @json_decode($resp, true);

  $resp_arr = ['status' => 'error', 'message' => ''];
  if (isset($data['ssoToken']) && !empty($data['ssoToken'])) {
    if (
      file_put_contents($DATA_FOLDER . "/creds.jtv", encrypt_data(json_encode($data), $u_name)) &&
      file_put_contents($DATA_FOLDER . "/credskey.jtv", $u_name)
    ) {
      $resp_arr['status'] = 'success';
      $resp_arr['message'] = 'JioTV Login Successful!';
    } else {
      $resp_arr['message'] = 'Login OK but failed to save data';
    }
  } else {
    $msg = $data['message'] ?? '';
    if (!$msg && isset($data['errors']) && $data['errors']) {
      $msg = $data['errors'][0]['message'] ?? '';
    }
    $resp_arr['message'] = $msg ?: "Verify failed: " . $info['http_code'];
  }
  return $resp_arr;
}

function refresh_jio_token()
{
  $DATA_FOLDER = "../assets/data";
  $filePath = $DATA_FOLDER . "/creds.jtv";
  $key_data = file_get_contents($DATA_FOLDER . "/credskey.jtv");
  $cred_data = decrypt_data(file_get_contents($filePath), $key_data);
  $JIO_AUTH = json_decode($cred_data, true);

  if (!empty($JIO_AUTH)) {
    $ref_TokenApi = "https://auth.media.jio.com/tokenservice/apis/v1/refreshtoken?langId=6";
    $ref_TokenPost = '{"appName":"RJIL_JioTV","deviceId":"' . $JIO_AUTH['deviceId'] . '","refreshToken":"' . $JIO_AUTH['refreshToken'] . '"}';
    $ref_TokenHeads = array(
      "accesstoken: " . $JIO_AUTH['authToken'],
      "uniqueId: " . $JIO_AUTH['sessionAttributes']['user']['unique'],
      "devicetype: phone",
      "versionCode: 331",
      "os: android",
      "Content-Type: application/json"
    );
    $process = curl_init($ref_TokenApi);
    curl_setopt($process, CURLOPT_POST, 1);
    curl_setopt($process, CURLOPT_POSTFIELDS, $ref_TokenPost);
    curl_setopt($process, CURLOPT_HTTPHEADER, $ref_TokenHeads);
    curl_setopt($process, CURLOPT_HEADER, 0);
    curl_setopt($process, CURLOPT_TIMEOUT, 10);
    curl_setopt($process, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($process, CURLOPT_FOLLOWLOCATION, 1);
    $ref_data = json_decode(curl_exec($process), true);
    curl_close($process);

    if (isset($ref_data['authToken']) && !empty($ref_data['authToken'])) {
      $JIO_AUTH["authToken"] = $ref_data['authToken'];
      $new_auth = json_encode($JIO_AUTH);
      $key_data = file_get_contents($DATA_FOLDER . "/credskey.jtv");
      file_put_contents($DATA_FOLDER . "/creds.jtv", encrypt_data($new_auth, $key_data));
      return ["status" => "success", "message" => "Token refreshed!"];
    }
  }
  return ["status" => "error", "message" => "Refresh failed"];
}

// Handle admin login
$isLoggedIn = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
  if ($_POST['action'] === 'admin_login') {
    if ($_POST['password'] === $ADMIN_PASSWORD) {
      $_SESSION['admin_logged_in'] = true;
      $isLoggedIn = true;
    } else {
      $error = 'Wrong password!';
    }
  }
  if ($_POST['action'] === 'admin_logout') {
    session_destroy();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
  }
  if ($_POST['action'] === 'send_otp' && $isLoggedIn) {
    $mobile = $_POST['mobile'] ?? '';
    if (preg_match('/^\d{10}$/', $mobile)) {
      $result = send_jio_otp($mobile);
      if ($result['status'] === 'success') {
        $_SESSION['pending_mobile'] = $mobile;
        $error = 'OTP sent to ' . htmlspecialchars($mobile);
      } else {
        $error = $result['message'];
      }
    } else {
      $error = 'Enter valid 10-digit mobile number';
    }
  }
  if ($_POST['action'] === 'verify_otp' && $isLoggedIn) {
    $otp = $_POST['otp'] ?? '';
    $mobile = $_SESSION['pending_mobile'] ?? '';
    if (preg_match('/^\d{6}$/', $otp) && $mobile) {
      $result = verify_jio_otp($mobile, $otp);
      if ($result['status'] === 'success') {
        unset($_SESSION['pending_mobile']);
        $error = 'Login successful! Users can now watch channels.';
      } else {
        $error = $result['message'];
      }
    } else {
      $error = 'Enter valid 6-digit OTP';
    }
  }
  if ($_POST['action'] === 'refresh' && $isLoggedIn) {
    $result = refresh_jio_token();
    $error = $result['message'];
  }
  if ($_POST['action'] === 'logout_jio' && $isLoggedIn) {
    $files = ["../assets/data/creds.jtv", "../assets/data/credskey.jtv"];
    foreach ($files as $f) {
      if (file_exists($f)) unlink($f);
    }
    $error = 'JioTV logged out. Please login again.';
  }
}

$credsExist = file_exists("../assets/data/creds.jtv") && file_exists("../assets/data/credskey.jtv");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - JioTV+</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .gradient-text {
            background: linear-gradient(45deg, #8B5CF6, #EC4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .glass-effect {
            background: rgba(17, 24, 39, 0.8);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="bg-gray-900 text-gray-100 min-h-screen flex items-center justify-center p-4">

    <?php if (!$isLoggedIn): ?>
    <!-- Admin Login -->
    <div class="glass-effect rounded-2xl shadow-2xl w-full max-w-md p-8">
        <div class="text-center mb-8">
            <img src="https://i.ibb.co/BcjC6R8/jiotv.png" alt="JioTV Logo" class="w-24 h-24 mx-auto mb-4 filter brightness-125">
            <h1 class="text-3xl font-bold gradient-text mb-2">Admin Panel</h1>
            <p class="text-gray-400">Enter password to manage JioTV</p>
        </div>
        <?php if ($error): ?>
        <div class="mb-6 p-3 bg-red-900 text-red-300 rounded-lg"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="hidden" name="action" value="admin_login">
            <div class="mb-4">
                <label class="block text-gray-300 mb-2">Password</label>
                <input type="password" name="password" required
                    class="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-600 text-gray-100"
                    placeholder="Enter admin password">
            </div>
            <button type="submit"
                class="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 rounded-lg font-medium transition-all">
                Login
            </button>
        </form>
        <div class="mt-6 text-center">
            <a href="../../index.php" class="text-purple-400 hover:text-purple-300">&larr; Back to Home</a>
        </div>
    </div>

    <?php else: ?>
    <!-- Admin Dashboard -->
    <div class="glass-effect rounded-2xl shadow-2xl w-full max-w-lg p-8">
        <div class="text-center mb-8">
            <img src="https://i.ibb.co/BcjC6R8/jiotv.png" alt="JioTV Logo" class="w-20 h-20 mx-auto mb-4 filter brightness-125">
            <h1 class="text-3xl font-bold gradient-text mb-2">Admin Panel</h1>
            <p class="text-gray-400">JioTV Login Management</p>
        </div>

        <?php if ($error): ?>
        <div class="mb-6 p-3 <?= strpos($error, 'successful') !== false || strpos($error, 'refreshed') !== false ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300' ?> rounded-lg">
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <div class="mb-6 p-4 rounded-lg <?= $credsExist ? 'bg-green-900/50 border border-green-700' : 'bg-red-900/50 border border-red-700' ?>">
            <p class="text-sm">
                Status: <?= $credsExist ? '<span class="text-green-300 font-bold">Logged In</span> (Users can watch)' : '<span class="text-red-300 font-bold">Not Logged In</span> (Users cannot watch)' ?>
            </p>
        </div>

        <?php if (isset($_SESSION['pending_mobile'])): ?>
        <!-- OTP Verify -->
        <form method="POST" class="space-y-4">
            <input type="hidden" name="action" value="verify_otp">
            <div>
                <label class="block text-gray-300 mb-2">Enter OTP sent to <?= htmlspecialchars($_SESSION['pending_mobile']) ?></label>
                <input type="text" name="otp" required maxlength="6" minlength="6"
                    class="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-600 text-gray-100 text-center tracking-widest"
                    placeholder="123456">
            </div>
            <button type="submit"
                class="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 rounded-lg font-medium transition-all">
                Verify OTP
            </button>
        </form>
        <?php else: ?>
        <!-- Send OTP -->
        <form method="POST" class="space-y-4">
            <input type="hidden" name="action" value="send_otp">
            <div>
                <label class="block text-gray-300 mb-2">Jio Mobile Number</label>
                <input type="text" name="mobile" required maxlength="10" minlength="10"
                    class="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-600 text-gray-100"
                    placeholder="9876543210">
            </div>
            <button type="submit"
                class="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 rounded-lg font-medium transition-all">
                Send OTP
            </button>
        </form>

        <!-- Actions -->
        <div class="mt-6 grid grid-cols-2 gap-3">
            <form method="POST">
                <input type="hidden" name="action" value="refresh">
                <button type="submit"
                    class="w-full py-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-all text-sm">
                Refresh Token
                </button>
            </form>
            <form method="POST">
                <input type="hidden" name="action" value="logout_jio">
                <button type="submit"
                    class="w-full py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-all text-sm">
                Logout JioTV
                </button>
            </form>
        </div>
        <?php endif; ?>

        <div class="mt-6 border-t border-gray-700 pt-4 text-center">
            <form method="POST" class="inline">
                <input type="hidden" name="action" value="admin_logout">
                <button type="submit" class="text-gray-400 hover:text-white text-sm">Admin Logout</button>
            </form>
            <span class="mx-3 text-gray-600">|</span>
            <a href="../../index.php" class="text-purple-400 hover:text-purple-300 text-sm">Back to Home &rarr;</a>
        </div>
    </div>
    <?php endif; ?>

</body>
</html>
